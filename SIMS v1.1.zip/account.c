#include "student.h"
#include "account.h"
#define MAX 500



void configToPath(){
	char line1[128] = {0};
	char line2[128] = {0};
	FILE *fp_stu_info;
	FILE *fp_config;

	strcpy(path_config,"config.txt"); 

	fp_config = fopen(path_config,"r");
	fgets(line1, sizeof(line1), fp_config);
	line1[strlen(line1)-1] = '\0';
	strcpy(path_stu_info , line1);

	fgets(line2, sizeof(line2), fp_config);
	strcpy(path_account_info , line2);
	fclose(fp_config);
}

int acConfirm(pac_t arr, char name[],char password[]){
	int i = 0;
	for(i = 0;i<ACLEN;i++){

		if(0 == strcmp(name ,arr[i].ac_name) && 0 == strcmp(password ,arr[i].ac_password)){
			SHOW_TYPE = arr[i].ac_type;
			return arr[i].ac_type;
		}
			
	}
	printf("û�и��˻�.");
			return 0;
}



pac_t acInit(){

	char line [128];
	FILE *fp_ac;
	pac_t acArr;
	int index =0;

	ACLEN = 0;

	acArr = (pac_t)calloc(MAX, sizeof(ac_t));
	fp_ac = fopen(path_account_info ,"r");
	memset(line, 0, sizeof(line));//��ʹ��֮ǰ��ʼ��
	while(memset(line, 0, sizeof(line)),fgets(line ,sizeof(line),fp_ac)!= NULL){
		sscanf(line , "%s%s%d" ,acArr[index].ac_name,acArr[index].ac_password,&acArr[index].ac_type);
		index++;
	}

	ACLEN = index;

	return acArr;
}

int acSearchByName(pac_t arr ,char name[]){
	int i = 0;
	for(i = 0;i<ACLEN;i++){

		if(0 == strcmp(name ,arr[i].ac_name) ){
			SHOW_TYPE = arr[i].ac_type;
			printf("%10s%10s%2d /n",arr[i].ac_name ,arr[i].ac_password ,arr[i].ac_type);
			return i;
		}
			
	}	
	return -1;
}

void acInsert(pac_t arr){
	char name[20] = {0};
	char password[20] = {0};
	int type = 0;
	int index = 0;
	
	printf("������Ҫ���ӵ��˻���Ϣ��");
	scanf("%s%s%d",name ,password ,&type);

	if(acSearchByName(arr,name)){
		strcpy(arr[ACLEN].ac_name, name);
		strcpy(arr[ACLEN].ac_password, password);
		arr[ACLEN].ac_type = type;
		printf("����ɹ�\n");
		ACLEN++;
		return ;
	}else{
		printf("����ʧ��\n");
		return ;
	}
}

void acDelect(pac_t arr){
	char name[20] = {0};
	char password[20] = {0};
	int type = 0;
	int index = 0;
	
	printf("������Ҫɾ�����û�����");
	scanf("%s",name);

	index = acSearchByName(arr,name);
	if(index>=0){
		printf("%10s%10s%1d �Ѿ�ɾ��\n",arr[index].ac_name, arr[index].ac_password,arr[index].ac_type);
		while(index<ACLEN-1){
			arr[index]=arr[index+1];
			index++;
		}
		ACLEN--;
		return ;
	}else{
		printf("ɾ��ʧ��\n");
		return ;
	}	
}

void acUpdata(pac_t arr){
	int index = 0;
	char name[128] = {0};
	printf("������Ҫ���ĵ��û�����");
	scanf("%s",name);
	index = acSearchByName(arr ,name);
	if(index<ACLEN){
		printf("��������ĵ��û���Ϣ");
		fflush(stdin);
		scanf("%s%d",arr[index].ac_password ,&arr[index].ac_type);
		printf("%10s%10s%2d �Ѿ�����\n",arr[index].ac_name, arr[index].ac_password,arr[index].ac_type);
		return ;
	}else{
		printf("����ʧ��\n");
		return ;
	}	
}

void acShow(pac_t arr){
	int index = 0;
	for(index =0 ; index < ACLEN; index++){
		printf("%10s%10s%2d \n",arr[index].ac_name , arr[index].ac_password, arr[index].ac_type);
	}
}
