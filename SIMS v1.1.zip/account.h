
#ifndef __ACCOUNTC__
#define __ACCOUNTC__

#include "student.h"
char path_config[1024];//�ַ������ʹ���ַ����������ָ��
char path_stu_info[1024];
char path_account_info[1024];
int ACLEN;

typedef struct account{
	char ac_name[20];
	char ac_password[20];
	int ac_type;
}ac_t,*pac_t;

void configToPath();
pac_t acInit();
int acConfirm(pac_t arr,char name[],char password[]);
void acInsert(pac_t arr);
void acUpdata(pac_t arr);
void acDelect(pac_t arr);
int acSearchByName(pac_t arr,char name[]);
void acSearch(pac_t arr);

void acShow(pac_t arr);
#endif