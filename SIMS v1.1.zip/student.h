#ifndef __STUDENTC__
#define __STUDENTC__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <math.h>
#include "account.h"

#define __DISPALY__LAND__ 0
#define __DISPALY__MANGEROP__ 1
#define __DISPALY__STUDENT__ 2

int SHOW_TYPE;

typedef struct student{
	int st_id;
	char st_name[20];
	double st_score;
	struct student* st_next;

}stu_t,*pstu_t;



pstu_t studIiitTail( );
pstu_t stuInitHead( );
pstu_t stuInitSort( );

void stuShow(pstu_t phead);

void stuDestory(pstu_t* pphead);


void stuDelete(pstu_t * pphead, int id);
//void stuDelete(pstu_t * pphead, double score);

void showStuSearch(pstu_t *phead, int show_type);

void showMain(pac_t arr,pstu_t *pphead,int show_type);

void stuInsertSort(pstu_t *pphead);

void stuUpdata(pstu_t *pphead ,int id);

pstu_t stuSearchById(pstu_t phead,int id);

pstu_t stuSearchByName(pstu_t phead,char name[]);

void stuSave(pstu_t phead ,pac_t arr);

#endif