#include <string.h>
#include "student.h"
#include <conio.h>

const char manager_main_option[] = 
	{
"			 1. search student information;\n"	
" 			 2. add student information;\n"	
"			 3. delete student information;\n"
"			 4. updata student information;\n"
"			 5. add user account;\n"
"			 6. updata user account;\n"
"			 7. delete user account;\n"
"			 8. search user account;\n"
"			 0. exit;\n"			  
	};

const char stu_main_option[] = 
	{
"			 1. search student information;\n"
"			 0. exit;\n "			  
	};


const char land_option[] = 
	{
"			 1. user land;\n"	
"			 0. exit;\n"			  
	};


const char manger_search_option[] ={
"			 1. search all;\n"	
"			 2. search by id;\n"
"			 3. search by name;\n"	
};

const char manger_ac_search_option[] ={
"			 1. search all;\n"	
"			 2. search by name;\n"
};

const char student_ac_search_option[] ={
"			 2. search by name;\n"
};
const char student_search_option[] ={
"			 2. search by id;\n"
"			 3. search by name;"
};

void showStuSearch(pstu_t phead ,int show_type){
	int op = -1;
	int id = -1;
	pstu_t pt = NULL;
	char name[128] = {0};
	system("cls");
	printf("***************************SIMSv1.0 2015.05.07 **************************\n");
	switch(show_type){
		case 1:
			printf("%s",manger_search_option);
			break;
		case 2:
			printf("%s",student_search_option);
			break;
	}
	printf("*****************************AUTHOR:Ktry*******************************\n");
	if(1 == SHOW_TYPE){
		do{
		fflush(stdin);
		printf( "��ѡ��һ�����:\n");
		scanf("%d",&op);
		}while(op<1||op>3);
	}else{
		do{
		fflush(stdin);
		printf( "��ѡ��һ�����:\n");
		scanf("%d",&op);
		}while(op<2||op>3);
	}
	switch(op) {
	case 1:
		stuShow(phead);
		break;
	case 2:
		printf("������Ҫ���ҵ�ѧ��ѧ�ţ� ");
		scanf("%d",&id);
		pt = stuSearchById(phead,id);
		if(pt == NULL)
			printf("�鲻����ѧ����Ϣ");
		break;
	case 3:
		printf("������Ҫ���ҵ�ѧ�������� ");
		scanf("%s",name);
		pt = stuSearchByName(phead,name);
		if(pt == NULL)
			printf("�鲻����ѧ����Ϣ");
		break;
	case 0:
		return;
	}
}

void showAcSearch(pac_t arr){
	char password[128] = {0};
	char name[128] = {0};
	int op = -1;

	system("cls");
	printf("***************************SIMSv1.0 2015.05.07 **************************\n");
	switch(SHOW_TYPE){
		case 1:
			printf("%s",manger_ac_search_option);
			break;
		case 2:
			printf("%s",student_ac_search_option);
			break;
	}
	printf("*****************************AUTHOR:Ktry*******************************\n");
	do{
	fflush(stdin);
	printf( "��ѡ��һ�����:\n");
	scanf("%d",&op);
	}while(op<1||op>2);

	switch(op) {
	case 1:
		acShow(arr);
		break;
	case 2:
		printf("������Ҫ�����û����û���: ");
		scanf("%s",name);
		acSearchByName(arr,name);
		break;
	}
}





void showMain(pac_t arr,pstu_t* pphead, int show_type){
	int op = -1 ,id = -1;
	int ac_ps = 0;
	char ac_name[20]= {0};
	char ac_password [20] = {0};
	int ac_t = 0;
	system("cls");
	printf("***************************SIMSv1.0 2015.05.07 **************************\n");
	switch(show_type){
		case 0:
			printf("%s", land_option);
			break;
		case 1:
			printf("%s",manager_main_option);
			break;
		case 2:
			printf("%s",stu_main_option);
			break;
	}
	printf("*****************************AUTHOR:Ktry*********************************\n");
	if(0 == show_type){
		do{
		fflush(stdin);
		printf( "��ѡ��һ�����:\n");
		scanf("%d",&op);
		}while(op!=1&&op!=0);
		switch(op){
		case 1:
			  printf("�������û���:");
			  scanf("%s", ac_name);
			  printf("����������:");
			  fflush(stdin);
			  while( (ac_ps >= 0) && (ac_password[ac_ps++]=getch()) != 35 ){
				  if('\b' == ac_password[0]){
					ac_ps = 0;
					continue;
				  }else if('\b' == ac_password[ac_ps-1]){
					printf("%c%c%c",'\b','\0','\b');
					ac_ps -= 2;
				  }else{
					printf("*");
				  }
			  }
			  ac_password[--ac_ps] = '\0';
			  acConfirm(arr,ac_name ,ac_password);
			  break;
		case 0:
			exit(0);
		}
	}
	else{
	if(1 == SHOW_TYPE){
		do{
		fflush(stdin);
		printf( "��ѡ��һ�����:\n");
		scanf("%d",&op);
		}while(op<0||op>8);
	}else{
		do{
		fflush(stdin);
		printf( "��ѡ��һ�����:\n");
		scanf("%d",&op);
		}while(op<0||op>1);
	}
		switch (op){
		case 1:
			showStuSearch(*pphead ,SHOW_TYPE);
			break;
		case 2:
			stuInsertSort(pphead);
			break;
		case 3:
			printf("������Ҫɾ����ѧ��ѧ�ţ�");
			scanf("%d",&id);
			stuDelete(pphead,id);
			break;
		case 4:
			printf("������Ҫ���µ�ѧ��ѧ�ţ�");
			scanf("%d",&id);
			stuUpdata(pphead,id);
			break;
		case 5:
			acInsert(arr);
			break;
		case 6:
			acUpdata(arr);
			break;
		case 7:
			acDelect(arr);
			break;
		case 8:
			showAcSearch(arr);
			break;
		case 0:
			stuSave(*pphead,arr);
		}
	}
}

