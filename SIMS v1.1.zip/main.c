#include "student.h"


int main(int argc, char * argv[]){
	pstu_t phead = NULL;
	int id = 0;
	
	char *name = NULL;
	pac_t acArr;

	SHOW_TYPE = __DISPALY__LAND__ ;
	configToPath();
	acArr = acInit();
	phead = stuInitSort();
	
	while(1){
		showMain(acArr,&phead ,SHOW_TYPE);
		system("pause");	
		system("cls");
	}

	system("pause");
	return 0;
}